import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Loader from '../components/Loader';
import AssignUpdateForm from '../components/AssignUpdateForm';
import ErrorMessage from '../components/ErrorMessage';

import {
  getAllVehicles,
  getAllUpdatePackages,
  assignUpdateToVehicle,
} from '../service/api'; // Adjust path if needed

import './AssignUpdate.css';

function AssignUpdate() {
  const [vehicles, setVehicles] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [loadingData, setLoadingData] = useState(true);
  const [assigning, setAssigning] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    let cancelled = false;

    async function fetchData() {
      setLoadingData(true);
      setError('');

      try {
        const [vehiclesRes, updatesRes] = await Promise.all([
          getAllVehicles(),
          getAllUpdatePackages(),
        ]);

        if (!cancelled) {
          setVehicles(vehiclesRes.data.vehicles || []);
          setUpdates(updatesRes.data.updates || []);
        }
      } catch (err) {
        if (cancelled) return;
        let msg = 'Failed to load data.';
        if (err.response?.data?.message) {
          msg = err.response.data.message;
        } else if (err.message) {
          msg = err.message;
        }
        setError(msg);
      } finally {
        if (!cancelled) setLoadingData(false);
      }
    }

    fetchData();

    return () => {
      cancelled = true;
    };
  }, []);

  const onAssignUpdate = async (vehicleId, updateId) => {
    setAssigning(true);
    setError('');
    setSuccessMsg('');

    try {
      // Call backend API to assign update package to vehicle
      await assignUpdateToVehicle(vehicleId, { updateId });
      setSuccessMsg('Update assigned successfully!');
    } catch (err) {
      let msg = 'Failed to assign update.';
      if (err.response?.data?.message) {
        msg = err.response.data.message;
      } else if (err.message) {
        msg = err.message;
      }
      setError(msg);
    } finally {
      setAssigning(false);
    }
  };

  return (
    <div className="assignUpdateContainer">
      <Navbar />

      {error && <ErrorMessage message={error} />}
      {successMsg && <div className="successMessage">{successMsg}</div>}

      {loadingData ? (
        <Loader />
      ) : (
        <AssignUpdateForm
          vehicles={vehicles}
          updates={updates}
          onAssignUpdate={onAssignUpdate}
          disabled={assigning}
        />
      )}

      {assigning && !loadingData && (
        <div className="assigningLoaderWrapper">
          <Loader />
          <p>Assigning update...</p>
        </div>
      )}
    </div>
  );
}

export default AssignUpdate;
