import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Loader from '../components/Loader';
import ErrorMessage from '../components/ErrorMessage';
import './RegisteredVehicles.css';
import { getAllVehicles } from '../service/api';  // Make sure this path matches your project structure

function RegisteredVehicles() {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchVehicles() {
      setLoading(true);
      setError('');
      try {
        const response = await getAllVehicles();

        // Adjust to new backend response structure 
        // Make sure vehicles are in response.data.vehicles as before
        const vehiclesData = response.data?.vehicles || [];

        setVehicles(vehiclesData);
      } catch (err) {
        let errorMsg = 'Failed to load registered vehicles.';
        if (err.response?.data?.message) errorMsg = err.response.data.message;
        else if (err.message) errorMsg = err.message;
        setError(errorMsg);
      } finally {
        setLoading(false);
      }
    }
    fetchVehicles();
  }, []);

  return (
    <div className="wrapper">
      <Navbar />
      <main className="content">
        <h2>Registered Vehicles</h2>

        {loading && <Loader />}
        {error && <ErrorMessage message={error} />}
        {!loading && vehicles.length === 0 && <p>No vehicles registered yet.</p>}

        <div className="vehiclesGrid">
          {vehicles.map(vehicle => (
            <div className="vehicleCard" key={vehicle._id}>
              <h3>{vehicle.model}</h3>
              <p><strong>VIN:</strong> {vehicle.vin}</p>
              {vehicle.updateInProgress !== undefined && (
                <p>Status: {vehicle.updateInProgress ? 'Update In Progress' : 'Idle'}</p>
              )}
              {vehicle.assignedUpdate && (
                <p><strong>Assigned Update:</strong> {vehicle.assignedUpdate.name || 'N/A'}</p>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default RegisteredVehicles;
