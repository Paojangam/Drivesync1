import React from 'react';
import './Navbar.css';

function Navbar() {
  return (
    <nav className="navbar">
      <span className="brand">Vehicle Dashboard</span>
    </nav>
  );
}

export default Navbar;
