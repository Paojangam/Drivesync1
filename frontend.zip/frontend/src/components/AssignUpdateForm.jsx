import React, { useState } from 'react';
import './AssignUpdateForm.css';
import { useNavigate } from 'react-router-dom';

function AssignUpdateForm({ vehicles, updates, onAssignUpdate, disabled }) {
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [selectedUpdate, setSelectedUpdate] = useState('');
  const navigate = useNavigate();  // currently unused but available if needed

  // Use first vehicle/update _id as dummy fallback if none selected
  const dummyVehicleId = vehicles.length > 0 ? vehicles[0]._id : 'dummyVehicleId';
  const dummyUpdateId = updates.length > 0 ? updates[0]._id : 'dummyUpdateId';

  const handleSubmit = (e) => {
    e.preventDefault();

    const vehicleIdToSubmit = selectedVehicle || dummyVehicleId;
    const updateIdToSubmit = selectedUpdate || dummyUpdateId;

    onAssignUpdate(vehicleIdToSubmit, updateIdToSubmit);

    // Navigate to external website (currently hardcoded to YouTube)
    window.location.href = 'https://www.youtube.com/';
    
    // If you want to navigate internally instead, comment above and uncomment below:
    // navigate(`/vehicle/${vehicleIdToSubmit}`);
  };

  return (
    <form className="assignUpdateForm" onSubmit={handleSubmit}>
      <div className="formGroup">
        <label htmlFor="vehicle-select">Select Vehicle</label>
        <select
          id="vehicle-select"
          value={selectedVehicle}
          onChange={e => setSelectedVehicle(e.target.value)}
          disabled={disabled}
          required
        >
          <option value="">-- Select Vehicle --</option>
          {vehicles.map((vehicle) => (
            <option key={vehicle._id} value={vehicle._id}>
              {vehicle.name || vehicle.vin || vehicle._id}
            </option>
          ))}
        </select>
      </div>

      <div className="formGroup">
        <label htmlFor="update-select">Select Update</label>
        <select
          id="update-select"
          value={selectedUpdate}
          onChange={e => setSelectedUpdate(e.target.value)}
          disabled={disabled}
          required
        >
          <option value="">-- Select Update --</option>
          {updates.map((update) => (
            <option key={update._id} value={update._id}>
              {update.name}
            </option>
          ))}
        </select>
      </div>

      <button type="submit" className="submitButton" disabled={disabled}>
        Assign Update
      </button>
    </form>
  );
}

export default AssignUpdateForm;
