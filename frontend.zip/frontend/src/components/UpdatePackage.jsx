import React, { useEffect, useState } from 'react';
import Navbar from './Navbar';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';
import './UpdatePackage.css';
import {
  createUpdatePackage,          // should fetch vehicles of logged-in user
  getAllUpdatePackages,
  assignUpdateToVehicle
} from '../service/api'; // Adjust path to your api.js/service

function UpdatePackage() {
  const [vehicles, setVehicles] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [assigning, setAssigning] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // While loading or if no real data, show dummy card form
  const dummyVehicles = [
    { _id: 'dummy1', model: 'Tesla Model S', vin: '5YJSA1E26MF123456' },
  ];
  const dummyUpdates = [
    { _id: 'upd1', name: 'Firmware v1.0.1' },
  ];

  // Flag to decide if we display dummy (true before real data)
  const showDummy = loading || vehicles.length === 0 || updates.length === 0;

  useEffect(() => {
    async function fetchData() {
      setError('');
      setLoading(true);
      try {
        // Fetch real data when component mounts
        const [vehiclesRes, updatesRes] = await Promise.all([
          createUpdatePackage(),
          getAllUpdatePackages(),
        ]);
        setVehicles(vehiclesRes.data.vehicles || []);
        setUpdates(updatesRes.data.updates || []);
      } catch (err) {
        let msg = 'Failed to load data.';
        if (err.response?.data?.message) msg = err.response.data.message;
        else if (err.message) msg = err.message;
        setError(msg);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleAssign = async (vehicleId, updateId) => {
    setError('');
    setSuccessMsg('');
    setAssigning(true);
    try {
      await assignUpdateToVehicle(vehicleId, { updateId });
      setSuccessMsg('Update assigned successfully!');
    } catch (err) {
      let msg = 'Failed to assign update.';
      if (err.response?.data?.message) msg = err.response.data.message;
      else if (err.message) msg = err.message;
      setError(msg);
    } finally {
      setAssigning(false);
    }
  };

  // Handle form submit for dummy card - just go to a website
  const handleDummySubmit = (e) => {
    e.preventDefault();
    // Replace URL below with the website you want to go to
    window.location.href = 'https://www.example.com';
  };

  return (
    <div className="wrapper">
      <Navbar />
      <main className="content">
        <h2>My Vehicles - Update Packages</h2>

        {loading && <Loader />}
        {error && <ErrorMessage message={error} />}
        {successMsg && <div className="successMessage">{successMsg}</div>}

        <div className="vehicleCardsGrid">
          {showDummy ? (
            // Dummy card form
            <div className="vehicleCard">
              <h3>{dummyVehicles[0].model} <span className="vin">({dummyVehicles[0].vin})</span></h3>
              <form onSubmit={handleDummySubmit}>
                <div className="formGroup">
                  <label htmlFor="update-select-dummy">Select Update</label>
                  <select id="update-select-dummy" name="update-select" required defaultValue="">
                    <option value="" disabled>-- Select Update --</option>
                    {dummyUpdates.map(upd => (
                      <option key={upd._id} value={upd._id}>{upd.name}</option>
                    ))}
                  </select>
                </div>
                <button className="assignButton" type="submit">
                  Assign Update
                </button>
              </form>
            </div>
          ) : (
            // Real data cards
            vehicles.map(vehicle => (
              <div className="vehicleCard" key={vehicle._id}>
                <h3>{vehicle.model} <span className="vin">({vehicle.vin})</span></h3>
                <form
                  onSubmit={e => {
                    e.preventDefault();
                    const updateId = e.target.elements['update-select'].value;
                    handleAssign(vehicle._id, updateId);
                  }}
                >
                  <div className="formGroup">
                    <label htmlFor={`update-select-${vehicle._id}`}>Select Update</label>
                    <select
                      id={`update-select-${vehicle._id}`}
                      name="update-select"
                      required
                      defaultValue=""
                      disabled={assigning}
                    >
                      <option value="" disabled>-- Select Update --</option>
                      {updates.map(upd => (
                        <option key={upd._id} value={upd._id}>{upd.name}</option>
                      ))}
                    </select>
                  </div>
                  <button className="assignButton" type="submit" disabled={assigning}>
                    Assign Update
                  </button>
                </form>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}

export default UpdatePackage;
