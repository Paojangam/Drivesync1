import { BrowserRouter, Routes, Route } from "react-router-dom";
import AssignUpdate from "./pages/AssignUpdate";
import VehicleDetails from "./pages/VehicleDetails";
import RegisterVehicles from "./pages/RegisterVehicles";  // if this is under pages/
import UpdatePackage from "./components/UpdatePackage";     // if this is under pages/
import RegisteredVehicles from "./pages/RegisteredVehicles";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AssignUpdate />} /> {/* Example landing/redirect */}
        <Route path="/assign-update" element={<AssignUpdate />} />
        <Route path="/vehicle/:vin" element={<VehicleDetails />} />
        <Route path="/register" element={<RegisterVehicles />} />
                <Route path="/registered" element={<RegisteredVehicles />} />

        <Route path="/updatepackage" element={<UpdatePackage />} />
        <Route path="*" element={<div>Page not found</div>} /> {/* 404 fallback */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
